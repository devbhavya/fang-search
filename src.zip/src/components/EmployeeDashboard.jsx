const EmployeeDashboard = () =>{
    return(
        <div>sample</div>
    )
}

export default EmployeeDashboard