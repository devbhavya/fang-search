import React from 'react';
import './Search.css';
import Logo from './fanglogo.jpg';
import { Link } from 'react-router-dom';
function Search() { 
    return(
        <div className='starting_page'>
            <img src={Logo} alt="fang logo" className="search_bar_logo"></img>
        <form>
        <input class="search_bar" type="text" title="Search"></input><br></br>
        <Link to="/blank"><i className="bi bi-search starting_page_search"></i></Link>
        <Link to="/search"><button class="fang_search_button">Fang Search</button></Link>
        </form>
        <ul>
            <li><span style={{color:"orange"}}> Fang</span>  offered in: Hindi    </li>
            <li><span style={{color:"blue"}}>తెలుగు</span></li>
            <li>বাংলা</li>
            <li>Marati</li>
            <li>ગુજરાતી</li>
            <li>ಕನ್ನಡ</li>
            <li>ગુજરાતી</li>
            <li>മലയാളം</li>
        </ul>
        </div>
        );
    }
export default Search;