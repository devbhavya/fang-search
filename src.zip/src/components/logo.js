import React from 'react'
import fang from './images/fang-logo.svg'
import './logo.css'
const Logo = () => {
  return (
    <img className='logo' src={fang}></img>
  )
}

export default Logo;