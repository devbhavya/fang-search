import "./EmployeeListData.css";
const EmployeeListData = (props) =>{
    return(
        <>
            {
                props.data.map((eData)=>(
                    <div className="Employee_List-Data-Container">
                        <i  id="EmployeeProfile" class="bi bi-person-circle fa-3x"></i>
                        <p id="Employee-List-Employee-Name">{eData.name}</p>
                        <p id="Employee-List-Employee-Schedule">{eData.schedule}</p>
                        <p id="Employee-List-Employee-Dob">{eData.dob.getFullYear()}</p>
                        <hr id="Horizontal-Line"></hr>
                    </div>
                    
                ))
            }
        </>
    )
};
export default EmployeeListData;